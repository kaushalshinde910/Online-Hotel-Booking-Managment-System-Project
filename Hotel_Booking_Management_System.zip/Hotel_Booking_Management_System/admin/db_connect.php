<?php 

$conn= new mysqli('localhost','root','Shinde@789','hotel_db')or die("Could not connect to mysql".mysqli_error($con));
